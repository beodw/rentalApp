class Listing {
  String name;
  String price;
  String distanceFromYou;

  Listing(this.name, this.price, this.distanceFromYou);
}
