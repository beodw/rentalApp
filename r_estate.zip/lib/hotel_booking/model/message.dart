class Message {
	String text;
	bool fromMe;
	bool received;
	Message({required this.text, required this.fromMe, required this.received});
}