class User {
	String name;
	bool online;
	bool isLandLord;

	User({required this.name, required this.online, required this.isLandLord});
}
